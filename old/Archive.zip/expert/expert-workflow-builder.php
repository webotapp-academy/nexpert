<?php
// Define BASE_PATH
$BASE_PATH = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
$BASE_PATH = $BASE_PATH ? $BASE_PATH : '/';

// Check if user is logged in as expert
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'expert') {
    $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
    header('Location: ' . $BASE_PATH . '/index.php?panel=expert&page=auth');
    exit;
}

$page_title = "Workflow Builder - Nexpert.ai";
$panel_type = "expert";
require_once $_SERVER['DOCUMENT_ROOT'] . '/nexpert/includes/header.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/nexpert/includes/navigation.php';
?>
    <div class="max-w-7xl mx-auto px-4 py-8">

        <div class="grid lg:grid-cols-3 gap-8">
            <!-- Main Content -->
            <div class="lg:col-span-2 space-y-8">
                <!-- AI Template Section -->
                <div class="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-6 border border-purple-200">
                    <div class="flex items-center mb-4">
                        <div class="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center mr-4">
                            <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                            </svg>
                        </div>
                        <div>
                            <h2 class="text-xl font-semibold text-gray-900">AI-Powered Workflow Generator</h2>
                            <p class="text-gray-600 text-sm">Let AI create a customized workflow based on your expertise</p>
                        </div>
                    </div>
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">What type of workflow do you want to create?</label>
                            <select class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500">
                                <option>UX Design Mentorship Program</option>
                                <option>Business Strategy Consultation</option>
                                <option>Career Coaching Journey</option>
                                <option>Technical Skill Training</option>
                                <option>Creative Project Guidance</option>
                                <option>Custom Workflow</option>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Session Duration & Frequency</label>
                            <div class="grid grid-cols-2 gap-4">
                                <select class="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500">
                                    <option>4 weeks program</option>
                                    <option>8 weeks program</option>
                                    <option>12 weeks program</option>
                                    <option>Custom duration</option>
                                </select>
                                <select class="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500">
                                    <option>Weekly sessions</option>
                                    <option>Bi-weekly sessions</option>
                                    <option>One-time session</option>
                                </select>
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Workflow Description</label>
                            <textarea rows="4" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-sm" placeholder="Describe how you want the workflow to be structured. Include your teaching style, specific goals, key milestones, and any unique approaches you'd like to incorporate..."></textarea>
                            <p class="text-xs text-gray-500 mt-1">This description will help AI generate a workflow that matches your teaching style and objectives.</p>
                        </div>
                        
                        <button class="w-full bg-purple-600 text-white py-3 px-6 rounded-lg hover:bg-purple-700 transition font-semibold flex items-center justify-center">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                            </svg>
                            Generate AI Workflow
                        </button>
                    </div>
                </div>

                <!-- Manual Workflow Builder -->
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-xl font-semibold text-gray-900">Manual Workflow Builder</h2>
                        <button class="bg-accent text-white px-4 py-2 rounded-lg hover:bg-yellow-600 transition text-sm">
                            + Add Step
                        </button>
                    </div>
                    
                    <!-- Workflow Steps -->
                    <div class="space-y-6">
                        <!-- Step 1 -->
                        <div class="border border-gray-200 rounded-lg p-4">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-8 h-8 bg-accent text-white rounded-full flex items-center justify-center text-sm font-semibold mr-3">1</div>
                                    <h3 class="font-semibold text-gray-900">Discovery Session</h3>
                                </div>
                                <div class="flex space-x-2">
                                    <button class="text-gray-400 hover:text-gray-600">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path>
                                        </svg>
                                    </button>
                                    <button class="text-gray-400 hover:text-red-600">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                        </svg>
                                    </button>
                                </div>
                            </div>
                            
                            <div class="space-y-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">Step Description</label>
                                    <textarea rows="2" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent text-sm" placeholder="Describe what happens in this step...">Understanding learner's background, goals, and current skill level</textarea>
                                </div>
                                
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-1">Duration</label>
                                        <select class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent text-sm">
                                            <option>60 minutes</option>
                                            <option>90 minutes</option>
                                            <option>30 minutes</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-1">Deliverables</label>
                                        <input type="text" placeholder="Skills assessment, goals document" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent text-sm">
                                    </div>
                                </div>

                                <!-- Assignments for this step -->
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Pre-session Assignment</label>
                                    <div class="border border-gray-200 rounded-lg p-3 bg-gray-50">
                                        <input type="text" placeholder="Assignment title" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none mb-2 text-sm">
                                        <textarea rows="2" placeholder="Assignment description and instructions..." class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none text-sm"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Step 2 -->
                        <div class="border border-gray-200 rounded-lg p-4">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <div class="w-8 h-8 bg-accent text-white rounded-full flex items-center justify-center text-sm font-semibold mr-3">2</div>
                                    <h3 class="font-semibold text-gray-900">Foundation Building</h3>
                                </div>
                                <div class="flex space-x-2">
                                    <button class="text-gray-400 hover:text-gray-600">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path>
                                        </svg>
                                    </button>
                                    <button class="text-gray-400 hover:text-red-600">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                        </svg>
                                    </button>
                                </div>
                            </div>
                            
                            <div class="space-y-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">Step Description</label>
                                    <textarea rows="2" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent text-sm" placeholder="Describe what happens in this step...">Core principles and fundamental concepts introduction</textarea>
                                </div>
                                
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-1">Duration</label>
                                        <select class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent text-sm">
                                            <option>60 minutes</option>
                                            <option>90 minutes</option>
                                            <option>30 minutes</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-1">Deliverables</label>
                                        <input type="text" placeholder="Resource kit, practice exercises" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent text-sm">
                                    </div>
                                </div>

                                <!-- Assignments for this step -->
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Practice Assignment</label>
                                    <div class="border border-gray-200 rounded-lg p-3 bg-gray-50">
                                        <input type="text" placeholder="Assignment title" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none mb-2 text-sm">
                                        <textarea rows="2" placeholder="Assignment description and instructions..." class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none text-sm"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Add Step Button -->
                        <div class="text-center">
                            <button class="border-2 border-dashed border-gray-300 text-gray-500 py-4 px-6 rounded-lg hover:border-accent hover:text-accent transition flex items-center justify-center w-full">
                                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                                </svg>
                                Add Another Step
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Workflow Summary -->
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h2 class="text-xl font-semibold text-gray-900 mb-6">Workflow Summary</h2>
                    
                    <div class="space-y-4">
                        <div class="flex justify-between">
                            <span class="text-gray-600">Total Duration:</span>
                            <span class="font-semibold">4 weeks</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Number of Sessions:</span>
                            <span class="font-semibold">4 sessions</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Total Hours:</span>
                            <span class="font-semibold">6 hours</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Assignments:</span>
                            <span class="font-semibold">4 assignments</span>
                        </div>
                    </div>
                    
                    <div class="mt-6 pt-6 border-t border-gray-200">
                        <div class="flex justify-between items-center">
                            <span class="text-lg font-semibold text-gray-900">Recommended Price:</span>
                            <span class="text-2xl font-bold text-accent">₹5,400</span>
                        </div>
                        <p class="text-gray-500 text-sm mt-1">Based on your hourly rate and session count</p>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="space-y-6">
                <!-- Templates Library -->
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Template Library</h3>
                    
                    <div class="space-y-3">
                        <div class="border border-gray-200 rounded-lg p-3 hover:border-accent cursor-pointer transition">
                            <h4 class="font-medium text-gray-900 text-sm">UX Bootcamp</h4>
                            <p class="text-gray-600 text-xs">8-week comprehensive program</p>
                        </div>
                        
                        <div class="border border-gray-200 rounded-lg p-3 hover:border-accent cursor-pointer transition">
                            <h4 class="font-medium text-gray-900 text-sm">Career Transition</h4>
                            <p class="text-gray-600 text-xs">6-week guidance program</p>
                        </div>
                        
                        <div class="border border-gray-200 rounded-lg p-3 hover:border-accent cursor-pointer transition">
                            <h4 class="font-medium text-gray-900 text-sm">Skills Assessment</h4>
                            <p class="text-gray-600 text-xs">One-time evaluation session</p>
                        </div>
                        
                        <div class="border border-gray-200 rounded-lg p-3 hover:border-accent cursor-pointer transition">
                            <h4 class="font-medium text-gray-900 text-sm">Business Strategy</h4>
                            <p class="text-gray-600 text-xs">4-week consultation program</p>
                        </div>
                    </div>
                    
                    <button class="w-full mt-4 text-accent hover:text-yellow-600 text-sm font-medium">
                        Browse All Templates →
                    </button>
                </div>

                <!-- Quick Tips -->
                <div class="bg-green-50 rounded-lg p-6">
                    <h3 class="text-lg font-semibold text-green-900 mb-4">💡 Best Practices</h3>
                    <ul class="space-y-2 text-sm text-green-800">
                        <li class="flex items-start">
                            <span class="mr-2">•</span>
                            <span>Keep steps focused and actionable</span>
                        </li>
                        <li class="flex items-start">
                            <span class="mr-2">•</span>
                            <span>Include assignments between sessions</span>
                        </li>
                        <li class="flex items-start">
                            <span class="mr-2">•</span>
                            <span>Set clear deliverables for each step</span>
                        </li>
                        <li class="flex items-start">
                            <span class="mr-2">•</span>
                            <span>Allow flexibility for learner pace</span>
                        </li>
                    </ul>
                </div>

                <!-- Action Buttons -->
                <div class="space-y-3">
                    <button class="w-full bg-accent text-white py-3 px-6 rounded-lg hover:bg-yellow-600 transition font-semibold">
                        Save Workflow
                    </button>
                    <button class="w-full border border-gray-300 text-gray-700 py-3 px-6 rounded-lg hover:bg-gray-50 transition">
                        Save as Template
                    </button>
                    <button class="w-full bg-primary text-white py-3 px-6 rounded-lg hover:bg-secondary transition">
                        Publish & Make Available
                    </button>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>

<script>
    // Set BASE_PATH globally
    window.BASE_PATH = '<?php echo $BASE_PATH; ?>';

    // Utility function to resolve image paths
    function resolveImagePath(imagePath) {
        // If it's a full URL or a data URI, return as-is
        if (/^(https?:\/\/|data:)/.test(imagePath)) {
            return imagePath;
        }
        
        // If no image path, use a default
        if (!imagePath) {
            return `${window.BASE_PATH}/attached_assets/stock_images/diverse_professional_1d96e39f.jpg`;
        }
        
        // Remove leading slashes
        const normalizedPath = imagePath.replace(/^\/+/, '');
        
        // Construct full path
        return `${window.BASE_PATH}/${normalizedPath}`;
    }
</script>

<?php require_once $_SERVER['DOCUMENT_ROOT'] . '/nexpert/includes/footer.php'; ?>
